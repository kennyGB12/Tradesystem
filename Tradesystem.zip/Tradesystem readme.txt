Project introduction
.....................
Tradesystem.gov.ng is a web-based application trade facilitation tool for access to trade forms
(Forms NXP, NCX, A) and data and foreign exchange processes between users,banks, and stakeholders/ government institutions
in the trade chain.

STLC
......................
1) Understanding functional requirement specification (FRS)
2) Test Planning
3) Test scenarious ( what areas are to be tested)
4) Test cases (how to test the areas)
5) Test execution
6) Identify defects and write defect report
7) Test Completion

Understanding FRS
..................
. Interface navigation

. Applicant
 +Form A-Invisible Trades
 +Form NCX-Non-Commercial Exports
 +Form NXP-Commercial Exports 

.Authorized Dealer Bank (ADB)
 + Review submissions and validate exporters form
 + Review submissions and validate trade forms(form A, NCX, NXP)
 + Disburse funds

.Stakeholder/Goverment institutions (customs and other regulatory agencies)
 +Review and approve exported,imported goods and related documents

Test Execution
....................
Google chrome/ Microsoft Edge

Test Phases:
Smoke and sanity testing
FRS